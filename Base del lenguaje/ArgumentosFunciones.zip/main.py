print("+++++++++++++++++++++ArgumentosFunciones")


# Here, an empty list is used as a default argument of the function.
def append(number, number_list=[]):
    number_list.append(number)
    print(number_list)
    return number_list


def funcionConReturn():
    print('En funcionConReturn')
    return 'funcionConReturn'


def funcionSinReturn():
    print('En funcionSinReturn')


# Below are 3 calls to the `append` function and their expected and actual outputs:
append(5)  # expecting: [5], actual: [5]
append(7)  # expecting: [7], actual: [5, 7]
append(2)  # expecting: [2], actual: [5, 7, 2]

print

lista1 = [100, 200, 300]
lista2 = lista1
#mismo objetos con dos nombres

lista1.append(5000)
print(lista1)
print(lista2)
#si funcion no retorna nada, retorna igual algo llamado none
print(funcionConReturn())
print(funcionSinReturn())

# Variable check for None (usar mayusculas)
variable_name = None
if variable_name is None:
    print("variable is None")
else:
    print("variable is NOT None")


#Llamado con argumentos
# The function will take arg1 and arg2
def func_with_args(arg1, arg2):
    print(arg1 + ' ' + arg2)


func_with_args('First', 'Second')
# Prints:
# First Second

func_with_args(arg2='Second', arg1='First')
# Prints
# First Second
#--------------------------------------------
