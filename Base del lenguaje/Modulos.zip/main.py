print("+++++++++++++++++Modulos")
import datetime

nacimiento = datetime.date(1972, 11, 18)
hoy = datetime.date.today()
dentrodeunasemana = hoy + datetime.timedelta(days=7)

print("Hoy {hh}  nacimiento {nn} ".format(hh=hoy, nn=nacimiento))
print("dentro de Una SemaNa  " + str(dentrodeunasemana))
print('Dentro de una semana ' + dentrodeunasemana.strftime("%d/%m/%Y"))

anio = hoy.year
cumple = datetime.date(year=anio, month=nacimiento.month, day=nacimiento.day)
if (cumple < hoy):
    #esto serviria para sumar un año o mes
    #pip install python-dateutil
    #cumple=cumple+relativedelta(years=1, weeks=1)
    cumple = cumple + datetime.timedelta(days=365)
print(cumple)

##
import calendar as c


def mirar(texto):
    print('*******' + texto)
    print(c.weekday(cumple.year, cumple.month, cumple.day))
    print(cumple.isoweekday())
    print('dia de la semana formateado: ' + cumple.strftime("%A"))
    print('Mes nombre ' + c.month_name[cumple.month])
    print(c.month(cumple.year, cumple.month))


mirar("default ")
import locale
print(locale.getlocale())
locale.setlocale(locale.LC_ALL, ('en_US', 'UTF-8'))
mirar('segunda vez')
'''
locale -a muestra en consola que idiomas hay
To install a new locale use:
sudo apt-get install language-pack-id
where id is the language code  
After you have installed the locale you should follow Julien Palard advice and reconfigure the locales with:
sudo dpkg-reconfigure locales
'''
##########################################################################

import random
print("Tiremos los dados: ", end=' - ')
for x in range(30):
    dado = random.randint(1, 6)
    print(str(dado), end=' - ')
print("")

# Prints a random element from a sequence
seq = ["a", "b", "c", "d", "e"]
r2 = random.choice(seq)
print(r2)  # Random element in the sequence

print("Usando comillas 'dentro' de una frase parte 1")
print('Usando comillas "dentro" de una frase parte 2')
print('Usando comillas \'dentro\' de una frase parte 3')

import archivo2
archivo2.FuncionSegundoArchivo("Hello World segundo archivo")

import Tercero
Tercero.FuncionTercerArchivo("Tercer archivo")

#otra manera
# from module import *
#function()

#-------------------------------------