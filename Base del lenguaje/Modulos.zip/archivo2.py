def FuncionSegundoArchivo(texto):
    print('*******' + texto)
