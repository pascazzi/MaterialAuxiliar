print("+++++++++++++++++++PrimerosPasosHelloworld")
#name = input('What is your name?\n')
#print('Hi, %s.' % name)
print('inicio2')
resto = 17 % 3
print(resto)
resto += 1000
print(resto)

# Example integer numbers
chairs = 4
broken_chairs = -2

# Non-integer numbers
lights = 2.5
left_overs = 0.0

first = "Hello "
second = 'Fucking World'  #pueden ser simples tambien
result = first + second
long_result = first + second + "!"
print(long_result)

longer = "This string is broken up \
over multiple lines"

print(longer)
#----------------------------------------------
