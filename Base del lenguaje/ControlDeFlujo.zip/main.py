print("+++++++++++++++++++ControlDeFlujo")
#-------------------elif Statement
pet_type = "fish"
if pet_type == "dog":
    print("You have a dog.")
elif pet_type == "cat":
    print("You have a cat.")
elif pet_type == "fish":
    # this is performed
    print("You have a fish")
else:
    print("Not sure!")


#--------------------excepciones
def check_leap_year(year):
    is_leap_year = 'No'
    if year % 4 == 0:
        is_leap_year = 'SI'
    return is_leap_year


try:
    r1 = check_leap_year(2016)
    print(r1)
    print(is_leap_year)

except:
    print(' Atrape excepcion forzada')

#--------------------operadores
#igual
op1 = 80
op2 = 10
if op1 == op2:
    print('iguales ' + str(op1) + ' y ' + str(op2))
else:
    print('no iguales ' + str(op1) + ' y ' + str(op2))
#distinto
if op1 != op2:
    print('distintos ' + str(op1) + ' y ' + str(op2))
else:
    print('no distintos ' + str(op1) + ' y ' + str(op2))

#mayor o igual
if op1 >= op2:
    print('Mayor o igual ' + str(op1) + ' que ' + str(op2))
else:
    print('menor ' + str(op1) + ' que ' + str(op2))

#operadores logicos and or
if (op1 != op2 and (op1 < op2 or op1 == 80)):
    print('  SEEEE')
else:
    print('   Nahhh')
#operador not
if (not (1 == 2)):
    print('not 1==2 es true')
else:
    print('not 1==2 es false')

#bool
is_true = True
is_false = False

print(is_true)
print(is_false)
print(type(is_true))
print(type(op1))

#----------------------------------------------
