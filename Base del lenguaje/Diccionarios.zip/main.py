print("+++++++++++++++++++++++Diccionarios")
MiDiccionario1 = {"Lunes": "Monday", "Martes": "Tuesday"}
MiDiccionario1["Lunes"] = "Montag"  #existia lo pisa
MiDiccionario1["Miercoles"] = "Mittwoch"  #no existia lo agrega
MiDiccionario2 = {"Lunes": "Lundi", "Jueves": "Donnerstag", "Viernes": 5}

MiDiccionario1.update(MiDiccionario2)

print(MiDiccionario1["Lunes"])
print(MiDiccionario1["Martes"])
print(MiDiccionario1["Miercoles"])
print(MiDiccionario1["Jueves"])
print(MiDiccionario1["Viernes"])

print('-------- 2 ----------')
print(MiDiccionario1.get("Viernes"))
print(MiDiccionario1.get("Sabado"))  #no existe y no tengo default
print(MiDiccionario1.get("Domingo",
                         "Domingo No existe"))  #existe y tengo default

MiDiccionario1.update({"Enero": "January"})
print(MiDiccionario1.get("Enero", "Enero No existe"))
MiDiccionario1.pop("Enero")  #borro
print(MiDiccionario1.get("Enero", "Enero No existe"))

#Las claves solop ueden ser numeros int, float o strings.
MiDic3 = {
    1: 'hello',
    'two': True,
    '3': [1, 2, 3],
    'Four': {
        'fun': 'addition'
    },
    5.0: 5.5
}
print('----------- 3 ------------')
print(MiDiccionario1.keys())
print(MiDiccionario1.values())
print(MiDiccionario1.items())

print('----------- 4 ------------')
for k in MiDiccionario1.keys():
    if (MiDiccionario1[k] == 5):
        print("  Es cinco  :)")
        continue
    print(MiDiccionario1[k])

#----------------------------------------------------
