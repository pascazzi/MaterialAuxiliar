print("++++++++++++++++++++LISTAS")
primes = [2, 3, 5, 7, 11]
print(primes)

items = ['a', 'b', 'c']
total_items = items + ['d', 'e']
total_items += ['efe']
total_items.append('ge')
print(total_items)
total_items = ['-2', '-1'] + total_items
print(total_items)
total_items = []
print(total_items)
#------------------------------------------
numbers = [1, 2, 3, 4, 10]
names = ['Jenny', 'Sam', 'Alexis']
mixed = ['Jenny', 1, 2]
list_of_lists = [['a', 1], ['b', 2]]
print(list_of_lists)
#---------------------------------------
owners_names = ['pablo', 'marina', 'flor']
dogs_names = ['baisha', 'toby', 'Lola']
owners_dogs = zip(owners_names, dogs_names)
print(list(owners_dogs))

#--------------------------------------------
items = [
    'a1 indice0', 'b2 indice1', 'c3 indice2', 'd4indice3', 'e5indice4',
    'f6indice5'
]
print(items[:4])  # All items from index `0` to `3`
print(items[2:])  # All items from index `2` to the last item, inclusive
print(items[1])  #item index1 (segundo)
#- - - -
soups = ['minestrone', 'lentil', 'pho', 'laksa']
print(soups[-1])  # 'laksa'
print(soups[-3:])  # 'lentil', 'pho', 'laksa'
print(soups[:-2])  # 'minestrone', 'lentil'
#----------------
backpack = [
    'pencil', 'pen', 'notebook', 'textbook', 'pen', 'highlighter', 'pen'
]
numPen = backpack.count('pen')
print(numPen)
tamanio = len(backpack)
print(tamanio)
#The slice will include the START_NUMBER index, and everything until but excluding the END_NUMBER item.
losbook = backpack[2:4]
print(losbook)
#-------------------------
exampleList = [4, 2, 1, 3]
aux = sorted(exampleList)
print(exampleList)  # no cambia
print(aux)  # esta ordenada
exampleList.sort()
print(exampleList)  # esta ordenada

a = ['hola', 'chau']
a.append('alfondo!')
print(a)
print(len(a))
a.insert(1, 'segundo')
print(a)
print(len(a))
a[1] = 'second'
print(a)
a.remove('second')
print(a)
print(len(a))
del a[2]
print(a)
print(len(a))
a.sort()
print(a)
print(a[1])
#-------------------------
