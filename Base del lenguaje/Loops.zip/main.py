print("+++++++++++++++++LOOPS")
''''
while(True):
  a=input('HACE TU PREGUNTA: ')
  print('no')
'''

valores = [1972, 1974, 2020, 1950, 2025]
for val in valores:
    print(val)
    if (val == 2020):
        print('   pandemia')
        break  #break

result = [x**2 for x in range(10) if x % 2 == 0]  #listas expreciones
print(result)
# [0, 4, 16, 36, 64]

pot2 = [2**x for x in range(10)]  #for expresiones
print(pot2)

aux = [2**x for x in range(10) if x >= 1]
print(aux)

for x in range(1, 10 + 1):  #for numerico
    if (x == 5):
        print('cinco', end='-')
        continue  #continue
    print(x, end="-")
print('')

for x in range(3):
    print('3 veces Peligro')

maxi = 4
i = 1
while (i <= maxi):
    print('Warning: ' + str(i) + '/' + str(maxi), end=' ')
    i += 1
print('')

#imprimo una matrix
print('.......', end='  ')
for col in range(10):
    print(str(col) + '  ', end='  ')
print('')
for fila in range(5):
    print(str(fila), end='......')
    for col in range(10):
        print(str(fila) + '/' + str(col), end=' ')
    print('')

groups = [["Jobs", "Gates"], ["Newton", "Euclid"], ["Einstein", "Feynman"]]
# This outer loop will iterate over each list in the groups list
for group in groups:
    # This inner loop will go through each name in each list
    for name in group:
        print(name)

#--------------------------------------
