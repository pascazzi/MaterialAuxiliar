print("+++++++++++++++++++++Clase")
class Perro:
    nombre = 'Sin nombre aun'

    def __init__(self, nombre):
        self.nombre = nombre
        self.apellido = "no tiene apellido"

    def CambiarNombre(self, nuevonombre):
        self.nombre = nuevonombre

    def bark(self):
        print(self.nombre + " guau guau")

print("aeiou")
print(dir())
print('----------------------')
print(dir(Perro))
print('----------------------')
lola = Perro('Lola')
baisha = Perro('Baisha')

print(lola.nombre)
lola.CambiarNombre("Lolona")
print(lola.nombre)
lola.bark()

print(baisha.nombre)
print(baisha.apellido)
print(type(baisha))

print(dir())
print("  ")
print(dir(baisha))

print("---------------------------")
print(
    type(baisha)
)  #main: This means that the class CoolClass was defined in the current script file.

import anexo
puntito = anexo.Punto(1, 2)
print(type(puntito))

p1 = anexo.Punto(1, 10)
p2 = anexo.Punto(2, 20)
p3 = p1 + p2
print(p3)

#esto dispara exception a proposito:
try:
    print('* paso 1')
    puntito = anexo.Punto(1, 2)
    print('* paso 2')
    puntito = anexo.Punto(1, 'a')
    print('* paso 3')
    puntito = anexo.Punto(1, 2)
except IOError:
    print('error de io')
except ZeroDivisionError:
    print('division por cero no va')
except anexo.FuckException:
    print('    ..........Atrapo fuck exception')
except:
    print('salio algo mal pero no se que')
finally:
    print('* paso finally')

#############################

import herencia
boeing = herencia.avion('Boeing', 2)
boeing.definite()
boeing.categorias()
jumbo = herencia.avion('jumbo', 2)
jumbo.definite()
print(jumbo)

fiat = herencia.auto('fiat siena', 4)
fiat.definite()
print(fiat)

print(fiat + boeing)  #sumo ruedas 6

print(issubclass(herencia.avion, herencia.vehiculo))  # True
print(issubclass(herencia.auto, herencia.vehiculo))  # True
print(issubclass(herencia.auto, herencia.avion))  # falso

import MiBeep
MiBeep.beep()
#--------------------------------------