def FuncionTercerArchivo(texto):
    print('*******' + texto)
