print("+++++++++++++++++++++FILES")

with open('Notas.txt') as file_object:
    print('**file_object')
    print(file_object)  #datos del archivo, encoding etc.
    print('**READLINE')
    print(file_object.readline())

with open('Notas.txt') as file_object:
    file_data = file_object.readlines()
    text_data = file_object.read()

print('**file data*')
print(file_data)
print('**text data*')
print(text_data)

print('**Recorrer filedata*')
for ren in file_data:
    print(ren)

import random
with open('dados.txt', 'w') as dados:
    dados.write("Nuevo archivo\n")  #Lo abro con w entonces lo pisa

with open(
        'dados.txt', 'a'
) as dados:  #Lo abro con #a para agregar contenido. Si no existia esto lo crea
    for x in range(1, 10):
        tirada = random.randint(1, 6)
        print(tirada, end=' - ')
        dados.write(str(tirada) + " - ")
print(' ')
print('**************** JSON ***********************')
import json
with open('file.json') as json_file:
    python_dict = json.load(json_file)

print(python_dict.get('profesion'))
print(python_dict.get('nombreYAp'))

print(python_dict.get('empleados')[1])
print(len(python_dict.get('empleados')))
for empi in python_dict.get('empleados'):
    print(empi)
    print('El apellido es: ' + empi.get('apellido'))

print('***************** dictwriter *************')
# An example of csv.DictWriter
import csv

with open('companies.csv', 'w') as csvfile:
    fieldnames = ['name', 'type']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerow({'name': 'Codecademy', 'type': 'Learning'})
    writer.writerow({'name': 'Google', 'type': 'Search'})

with open('mascotas.csv', 'w') as miArchivo:
    campos = ['Nombre', 'Duenio', 'Apodo']
    writer = csv.DictWriter(miArchivo, fieldnames=campos)
    writer.writeheader()
    writer.writerow({'Nombre': 'Baisha', 'Duenio': 'Pablo', 'Apodo': 'Negra'})
    writer.writerow({'Duenio': 'Flor', 'Apodo': 'Lolona', 'Nombre': 'Lola'})
#---------------------------------
