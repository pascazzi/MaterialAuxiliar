print("+++++++++++++++++++++ESTILO LIBRE")


def edad():
    nacimiento = int(input('Anio de nacimiento: '))
    print(2021 - nacimiento)


edad()


def pideValor():
    mivalor = input('Valor?')
    return mivalor


lista = []
vale = pideValor()
while vale != '0':
    lista.append(vale)
    vale = pideValor()

lista.sort()
print(list(lista))

for i in range(len(lista)):
    print(lista[i] + '/', end='')

print('')
print('otra forma mas python')
for num in lista:
    print(num + '/', end='')
print('')
print('--------------------')

print(list(enumerate(lista, 700)))

for indice, item in enumerate(lista, 700):
    print("Elemento %d: %s." % (indice, str(item)))

datos = ['pablo', 'pasca', '1972']
nombre, apellido, edad = datos
print('Apellido: ' + apellido)

#--------------------------------------
